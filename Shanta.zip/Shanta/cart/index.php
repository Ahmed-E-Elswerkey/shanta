<?php 
	include_once '../initi.php';
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Shanta | Cart</title>
	<link rel="stylesheet" href="../css/cart.css">
	<script src='../js/cart.js'></script>
 <?php 
 	include_once '../navbar.php';

  ?>
  	<div id='cart_p'>
  		<h1>The Shopping Cart <?php $result2 = $GLOBALS['conn']->query("SELECT DISTINCT market_id FROM cache WHERE user_id='$_SESSION[user_id]'"); if($result2->num_rows > 0){echo "(".$result2->num_rows." market)";}  ?></h1>
  		<div id='cart_container'>
  			<div id='cart_details'>
  				<?php 
	  				$headers =  'MIME-Version: 1.0' . "\r\n"; 
					$headers .= 'From: Ahmed elswerk <ahemd@Gmail.com>' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

  					mail("ahmedelswerkey@gmail.com","php mail","hel",$headers);
  					$market_info = "";
  					$result1 = $GLOBALS['conn']->query("SELECT DISTINCT market_id FROM cache WHERE user_id='$_SESSION[user_id]' ORDER BY market_id");
  					$total_p = 0;
					if($result1->num_rows > 0){
						while($row1 = $result1->fetch_assoc()){
							$market = $GLOBALS['conn']->query("SELECT name,governorate FROM markets WHERE id='$row1[market_id]'");
							if($market){
								$mark = $market->fetch_assoc();
								$name = $mark['name'];
								$market_info .= "
									<div class='info_container'>
										<h3><span style=\"background: url('../uploads/".$row1['market_id'].".jpg');\">$name</span></h3>
										<p class='info'>
											Address: $mark[governorate]
										</p>
									</div>
									";
								echo "
									<div class='cart_market'>
										<h2 class='c_market_label'>$name</h2>
										<div class='c_market_body'>
								";
								$result = $GLOBALS['conn']->query("SELECT product_id,quantity,price FROM cache WHERE market_id='$row1[market_id]' AND user_id='$_COOKIE[user_id]'");
								if($result){
									while($row = $result->fetch_assoc()){
										$pro = $GLOBALS['conn']->query("SELECT name FROM products WHERE id='$row[product_id]'");
										if($pro){
											$rowp = $pro->fetch_assoc();
											echo "
												<div class='c_product'>
													<h3 class='c_p_name'>$rowp[name]</h3>
													<p class='c_p_p'>$".($row['price']/$row['quantity'])."</p>
													<p class='c_p_q'>$row[quantity]</p>
													<p class='c_p_totalp'>$row[price]</p>
												</div>
											";
											$total_p = $total_p + $row['price'];
										}
									}
								} 
								echo "</div></div>";
							}
							else "Error!";
						}
						echo "<div id='get_yrslf_info' class='floating'><div id='gys_container'>".$market_info."</div></div>";
					}
					else echo "<center><h1>Cart Is Empty</h1></center>";

  				 ?>
  			</div>
  		</div>
  	</div>
  			<div id='bill_total'>
  				<h1>Receipt</h1>
  				<?php  
  					if($total_p > 0)
  						echo "
  					<div id='bill_container'>
  						<div id='receive_type'>
							<h4>How to receive your Bag: <h4> 
							<div id='rec_sel'>
								<div>
									<button id='get_yrslf' class='no_verify' onclick='receive_way(this)' title='Come get your bag from the market and enjoy the journey'>Come and get it ;)</button>
									<button id='delivery' class='no_verify' onclick='receive_way(this)' title='Deliver the bag to you'>Deliver :)</button>
								</div> 
							</div>
  						</div>
						<p id='charge'>
							$total_p
							<span style='float:left;'>Total Charge:</span>
						</p>
  					</div>
  					<div id='checkout' style='' onclick='xml_checkout_b()' title='Finish buying and add the selected products to market's list>Checkout</div> ";
  				?>
  			</div>
  	<?php include_once '../footer.php'; ?>