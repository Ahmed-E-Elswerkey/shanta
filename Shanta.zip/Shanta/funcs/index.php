<?php
    include_once '../initi.php';

    if(isset($_COOKIE['user_id']))
        $uid = filter_var($_COOKIE['user_id']);
    // else header("Location: $_SESSION['de']");
    switch($_REQUEST['t'])
    {
        case "sign-in":sign_in();break;
        case "sign-up":sign_up();break;
        case "logout":logout();break;
        case "products-filling":product_filling();break;
        case "reset-password":reset_password($_REQUEST['e']);break;
        case "market-location":market_location($_REQUEST['g']);break;
        case "markets-build":markets_build();break;
        case "hello":hello();break;
        case "bill-add":bill_add($_REQUEST['pro']);break;
        case "bill-remove":bill_remove($_REQUEST['pro']);break;
        case "bill-edit":bill_edit($_REQUEST['pro'],$_REQUEST['q']);break;
        case "bill-trunc":bill_trunc();break;
        case "checkout-b":checkout_b();break;
        case "cart-f":cart_f($_REQUEST['ma']);break;
        case "markets-f":markets_f($_REQUEST['bid'],$_REQUEST['mid']);break;
        case "req-f":req_f($_REQUEST['bid'],$_REQUEST['mid']);break;
        case "bag-done":bag_done($_REQUEST['bid']);break;
        case "meals-add":meals_add();break;
        case "meals-b-f":meals_b_f();break;
        case "meals-pick":meals_pick();break;
        case "market-type-f":market_type_fill();break;
        case "market-update":market_update($_REQUEST['id']);break;
        case "search-out":search_out($_REQUEST['v']);break;
        case "movie":echo exec("D:\HOPPA1\MOVIES\2-ANIMATION\Finding Nemo (2003)\Finding.Nemo.2003.720p.BluRay.x264.YIFY.mp4").'sf';break;
        default:ob_end_clean();
        header("Location: $_SESSION[de]");
        break;
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function sign_in(){

        echo "sign_in";
        $email = filter_input(INPUT_POST,'user_email');
        $password =  $_POST['password'];
        $result = $GLOBALS['conn']->query("SELECT name,id,password,major FROM users WHERE email='$email'");
        $row = $result->fetch_assoc();
        if($row){
            if(password_verify($password,$row['password']))
            {
                echo "<br>password is good <br>";
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['name'];
                $_SESSION['user_email'] = $email;
                $_SESSION['major'] = $row['major'];
                $result1 = $GLOBALS['conn']->query("SELECT id FROM markets WHERE user_id='$_SESSION[user_id]'");
                $row = $result1->fetch_assoc();
                $_SESSION['market_id'] = $row['id'];
                setcookie("user_id",$_SESSION['user_id'],time()+(60*24*60*60),"/");
                setcookie("user_name",$_SESSION['user_name'],time()+(60*24*60*60),"/");
                setcookie("user_email",$_SESSION['user_email'],time()+(60*24*60*60),"/");
                setcookie("major",$_SESSION['major'],time()+(60*24*60*60),"/");
                $_SESSION['sign_error'] = "";
                header("Location: $_SESSION[de]");
                // die($_SESSION['de']);

            }
            else {echo $_SESSION['sign_error'] = "Password Wrong";header("Location: $_SESSION[de]/sign");}
        }
        else {$_SESSION['sign_error'] = "Email is wrong or doesn't exist";header("Location: $_SESSION[de]/sign");}
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function sign_up(){
        echo "sign_up";
        $name = filter_input(INPUT_POST,'user_name');
        $email = filter_input(INPUT_POST,'user_email');
        $major = filter_input(INPUT_POST,'major');
        $password = password_hash($_POST['password'],PASSWORD_BCRYPT);
        $result1 = $GLOBALS['conn']->query("SELECT email FROM users WHERE email='$email'");
        $row1=$result1->fetch_assoc();
        if(!$row1){
            $insert = $GLOBALS['conn']->query("INSERT INTO users (name,email,major,password) VALUES ('$name','$email','$major','$password')");
            $result = $GLOBALS['conn']->query("SELECT name,id,password,major FROM users WHERE email='$email'");
            $row = $result->fetch_assoc();
            if($row)
            {
                echo "<br> Everything is good <br>";
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                $_SESSION['major'] = $major;
                setcookie("user_id",$_SESSION['user_id'],time()+(60*24*60*60),"/");
                setcookie("user_name",$_SESSION['user_name'],time()+(60*24*60*60),"/");
                setcookie("user_email",$_SESSION['user_email'],time()+(60*24*60*60),"/");
                setcookie("major",$_SESSION['major'],time()+(60*24*60*60),"/");
                echo "<br>result ok<br>";
                $_SESSION['sign_error'] = "";
                header("Location: $_SESSION[de]");
            }
            else die("something happened!").$GLOBALS['conn']->error();
        }
        else {
            echo "<br>result not ok<br>";
            $_SESSION['sign_error'] = "Email is Already there!";
            header("Location: $_SESSION[de]/sign");
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function product_filling(){
        $name = filter_input(INPUT_POST,"name");
        $price = filter_input(INPUT_POST,"price");
        $type = filter_input(INPUT_POST,"type");
        $market_id = filter_input(INPUT_POST,"market_id");
        $GLOBALS['conn']->query("INSERT INTO products (name,price,type,market_id) VALUES ('$name','$price','$type','$market_id')");
        header("Location: $_SESSION[de]/products/?id=".$market_id);
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function logout(){
        // echo "asd";
        session_destroy();
        setcookie("user_name","",5,"/");
        setcookie("user_email","",5,"/");
        setcookie("user_id","",5,"/");
        setcookie("major","",5,"/");
        if (isset($_SERVER['HTTP_COOKIE'])) {
            $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
            foreach($cookies as $cookie) {
                $parts = explode('=', $cookie);
                $name = trim($parts[0]);
                setcookie($name, '', time()-1000);
                setcookie($name, '', time()-1000, '/');
            }
        }
        ob_clean();
        header("Location: $_SESSION[de]");
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    function reset_password($e){
        echo "$e";
        $result = $GLOBALS['conn']->query("SELECT password FROM users WHERE email='$e'");
        $row = $result->fetch_assoc();
        if($row){
            $headers = 'From: <daha.amd11212@gmail.com>' . "\r\n";
            mail('$e', 'Reset your passowrd', "If you didn't demand to reset your password, just ignore this<br>".$_SERVER['HTTP_HOST'].$_SESSION[de]."/funcs.php?t=password-reset&p=".$row['password'],$headers);
            echo "done";
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function market_type_fill(){
            $res = $GLOBALS['conn']->query("SELECT DISTINCT type FROM markets");
            if($res){
                    $row = $res->fetch_assoc();
                    echo "
                    <option>Products type...</option>
                    <option value='".$row['type']."'>".$row['type']."</option>
                    ";
                    while($row = $res->fetch_assoc()){
                            echo "<option value='".$row['type']."'>".$row['type']."</option>";
                    }
                    echo "<option value='others'>others</option>";
            }
            else echo "what!!";
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////
        function markets_build(){
            $conn = $GLOBALS['conn'];
            $res_id = $conn->query("SELECT max(id) FROM markets");
            if($res_id)
                    $row_id = $res_id->fetch_assoc();
            $mid = $row_id['max(id)']+1;      
            ///////////////////////////////////////////////////////////////////
             if(isset($_FILES['market_image'])){
                        echo "<br>upload is set<br>";
                        
                        $target_dir = $_SESSION[de]."/uploads/ ";
                        $ex = explode(".",$_FILES['market_image']['name']);
                        $_FILES['market_image']['name'] = $mid.".jpg";
                        echo $_FILES['market_image']['name'];
                        $target_file = $target_dir . basename($_FILES["market_image"]["name"]);
                        $uploadOk = 1;
                        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
                        // Check if image file is a actual image or fake image
                        
                            $check = getimagesize($_FILES["market_image"]["tmp_name"]);
                            if($check !== false) {
                                echo "File is an image - " . $check["mime"] . ".";
                                $uploadOk = 1;
                            } else {
                                echo "File is not an image.";
                                $uploadOk = 0;
                            }
                        
                        // Check if file already exists
                        if (file_exists($target_file)) {
                            unlink($target_file);
                            echo "Sorry, file already exists.";
                            $target_dir = $_SESSION[de]."/uploads/ ";
                        $ex = explode(".",$_FILES['market_image']['name']);
                        $_FILES['market_image']['name'] = $id.".jpg";
                        echo $_FILES['market_image']['name'];
                        $target_file = $target_dir . basename($_FILES["market_image"]["name"]);
                        $uploadOk = 1;
                        
                        }
                        // Check file size
                        if ($_FILES["market_image"]["size"] > 500000) {
                            echo "Sorry, your file is too large.";
                            $uploadOk = 0;
                        }
                        // Allow certain file formats
                        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                        && $imageFileType != "gif" ) {
                            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                            $uploadOk = 0;
                        }
                        // Check if $uploadOk is set to 0 by an error
                        if ($uploadOk == 0) {
                            echo "Sorry, your file was not uploaded.";
                        // if everything is ok, try to upload file
                        } else {
                            if (move_uploaded_file($_FILES["market_image"]["tmp_name"], $target_file)) {
                                echo "The file ". basename( $_FILES["market_image"]["name"]). " has been uploaded.";
                            } else {
                                echo "Sorry, there was an error uploading your file.";
                            }
                        }
                        echo "<br>process successfully done";
                        header("Location: $_SESSION[de]/home");
                    }
            else die( "where file!"); 
            ////////////////////////////////////////////
            $name = filter_input(INPUT_POST,"name");
            if(!empty($_POST['others']))
                $type = filter_input(INPUT_POST,"others");
            else $type = filter_input(INPUT_POST,"type");
            $telephone = filter_input(INPUT_POST,"telephone");
            if(!empty($_POST['telephone2']))
                $telephone .= ",".filter_input(INPUT_POST,"telephone2");
            $governorate = filter_input(INPUT_POST,"governorate");
            if(($conn->query("SELECT name FROM markets WHERE name='$name'")) === true)
            { $_SESSION['market_build_error'] = "the market is already there!";echo "not good";}
            else {
                $conn->query("INSERT INTO markets (name,type,telephones,governorate,user_id) VALUES ('$name','$type','$telephone','$governorate','$_SESSION[user_id]')");
                $result = $conn->query("SELECT id FROM markets WHERE name='$name'");
                $row = $result->fetch_assoc();
                $_SESSION['market_id'] = $row['id'];
                $_SESSION['market_name'] = $name;
                setcookie("market_id",$_SESSION['market_id'],time()+(60*24*60*60),"/");
                setcookie("market_name",$_SESSION['market_name'],time()+(60*24*60*60),"/");
                echo "good";
            }
            header("Location: $_SESSION[de]/home");
        }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    function market_location($a){
        $result = $GLOBALS['conn']->query("SELECT id,name,type,governorate,telephones FROM markets WHERE governorate='$a'");
        if($result){
            setcookie("last_loc",$a,time()+(30*24*60*60),"/");
            while($row = $result->fetch_assoc()){
                $result1 = $GLOBALS['conn']->query("SELECT count(id) as num FROM products WHERE market_id='$row[id]'");
                if($result1){
                    $row1 = $result1->fetch_assoc();
                    echo "
                                     <div class='market'>
                                          <a href='$_SESSION[de]/products/?id=$row[id]'><img class='m_i' src='$_SESSION[de]/uploads/$row[id].jpg'></a>
                                          <div style='width:100%;'><a class='m_n' href='$_SESSION[de]/products/?id=$row[id]'>$row[name]</a></div>
                                          <p class='m_t'>sells $row[type]</p>
                                          <a class='m_t' href='tel:$row[telephones]'>$row[telephones]</a>
                                          <p class='m_l' ><i class='fa fa-th' aria-hidden='true'></i> $row1[num] Products</p>
                                          <p class='m_l' ><i class='fa fa-map-marker' aria-hidden='true'></i> $row[governorate]</p>
                                      </div>
                                    ";
                    }
                    else echo $GLOBALS['conn']->error | mysqli_error();
            }
        }
        else echo $GLOBALS['conn']->error | mysqli_error();
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////
    function hello(){
        echo "hello";
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////
    function bill_add($pro){
        $result = $GLOBALS['conn']->query("SELECT price FROM products WHERE id='$pro'");
        if($result){
            $row = $result->fetch_assoc();
            $price = $row['price'];
            //echo "okay ".$price." user_id: ".$id."  ";
            $pro = filter_var($pro);
            $GLOBALS['conn']->query("INSERT INTO cache (user_id,product_id,market_id,quantity,price,date) VALUES ('$GLOBALS[uid]','$pro',(SELECT market_id FROM products WHERE id='$pro'),'1','$price',current_date())");
            $res = $GLOBALS['conn']->query("SELECT COUNT(num) FROM cache WHERE user_id='$GLOBALS[uid]'");
            if($res)
                $row = $res->fetch_assoc();
            echo $row['COUNT(num)'];
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function bill_edit($pro,$q){
        $result = $GLOBALS['conn']->query("SELECT price FROM products WHERE id='$pro'");
        if($result){
            $row = $result->fetch_assoc();
            $price = (($row['price'])*$q);

            $GLOBALS['conn']->query("UPDATE cache SET quantity='$q',price='$price' WHERE product_id='$pro' AND user_id='$GLOBALS[uid]'");
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////
    function bill_remove($pro){

        $GLOBALS['conn']->query("DELETE FROM cache WHERE product_id='$pro' AND user_id='$GLOBALS[uid]'");

        $res = $GLOBALS['conn']->query("SELECT COUNT(num) FROM cache WHERE user_id='$GLOBALS[uid]'");
        if($res)
            $row = $res->fetch_assoc();
        echo $row['COUNT(num)'];
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    function bill_trunc(){
        $GLOBALS['conn']->query("DELETE FROM cache WHERE user_id='$GLOBALS[uid]'");
        $res = $GLOBALS['conn']->query("SELECT COUNT(num) FROM cache WHERE user_id='$GLOBALS[uid]'");
        if($res)
            $row = $res->fetch_assoc();
        echo $row['COUNT(num)'];
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function cart_f($ma){
        if($ma == 'consumer'){
            $res = $GLOBALS['conn']->query("SELECT product_id,price,quantity FROM cache  WHERE user_id='$GLOBALS[uid]' ORDER BY market_id");
            if($res){
                echo "
                    <tr>
                     <th>Product</th>
                     <th>Quantity</th>
                     <th>price</th>
                     <th>market</th>
                    </tr>
                    ";
                while ($ro = $res->fetch_assoc()) {
                    $result_p = $GLOBALS['conn']->query("SELECT name,market_id FROM products WHERE id='$ro[product_id]'");
                    if ($result_p) {
                        $row_p = $result_p->fetch_assoc();
                        $result1 = $GLOBALS['conn']->query("SELECT name FROM markets WHERE id='$row_p[market_id]'");
                        $row1 = $result1->fetch_assoc();
                        echo "
                        <tr class='tr'>
                            <td>$row_p[name]</td>
                            <td>$ro[quantity]</td>
                            <td>$ro[price]</td>
                            <td>
                                <a href='$_SESSION[de]/products/?id=$row_p[market_id]'>
                                    $row1[name]
                                </a>
                            </td>
                        </tr>";
                    }
                }
            }
        }
        else if($ma == 'market_admin'){
            $res_o = $GLOBALS['conn']->query("SELECT market_id,bag_id FROM ");
        }


    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function markets_f($bid,$mid){
            $res = $GLOBALS['conn']->query("SELECT product_id,price,quantity FROM bags  WHERE user_id='$GLOBALS[uid]' AND id='$bid' AND market_id='$mid' ");
            if($res){
                $ro = $res->fetch_assoc();
                $t_p = 0;
                $result_p = $GLOBALS['conn']->query("SELECT name,market_id FROM products WHERE id='$ro[product_id]'");
                if($result_p) {
                    $row_p = $result_p->fetch_assoc();
                    $result1 = $GLOBALS['conn']->query("SELECT name FROM markets WHERE id='$row_p[market_id]'");
                    $row1 = $result1->fetch_assoc();
                    if(count($ro) >1) {
                        $t_p += $ro['price'];
                        echo "
                            <tr>
                             <th>Product</th>
                             <th>Quantity</th>
                             <th>price</th>

                        </tr>
                            <tr class='tr'>
                                <td>$row_p[name]</td>
                                <td>$ro[quantity]</td>
                                <td>$ro[price]</td>
        
            </tr>           ";
                        while ($ro = $res->fetch_assoc()) {
                            $result_p = $GLOBALS['conn']->query("SELECT name,market_id FROM products WHERE id='$ro[product_id]'");
                            if ($result_p) {
                                $t_p += $ro['price'];
                                $row_p = $result_p->fetch_assoc();
                                $result1 = $GLOBALS['conn']->query("SELECT name FROM markets WHERE id='$row_p[market_id]'");
                                $row1 = $result1->fetch_assoc();
                                echo "
                            <tr class='tr'>
                                <td>$row_p[name]</td>
                                <td>$ro[quantity]</td>
                                <td>$ro[price]</td>
        
            </tr>";
                            }
                        }
                        echo "
                            <tr style='border-top:1px solid #2b2b2b !important;border:solid thid'> <td>Total: </td> <td></td> <td>$$t_p</td> </tr>
                        ";
                    }
                    else echo " ";
                }
                else echo $GLOBALS['conn']->error;
            }
                else echo $GLOBALS['conn']->error.mysqli_error();;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function req_f($bid,$mid){
            $res = $GLOBALS['conn']->query("SELECT product_id,price,quantity FROM bags  WHERE id='$bid' AND market_id='$mid' ");
            if($res){
                $ro = $res->fetch_assoc();
                $result_p = $GLOBALS['conn']->query("SELECT name,market_id FROM products WHERE id='$ro[product_id]'");
                if($result_p) {
                    $row_p = $result_p->fetch_assoc();
                    $result1 = $GLOBALS['conn']->query("SELECT name FROM markets WHERE id='$row_p[market_id]'");
                    $row1 = $result1->fetch_assoc();
                    if(count($ro) >1) {
                        echo "
                            <tr>
                             <td>Product</td>
                             <td>Quantity</td>
                            </tr>
                            <tr class='tr'>
                                <td>$row_p[name]</td>
                                <td>$ro[quantity]</td>
        
                            </tr>";
                        while ($ro = $res->fetch_assoc()) {
                            $result_p = $GLOBALS['conn']->query("SELECT name,market_id FROM products WHERE id='$ro[product_id]'");
                            if ($result_p) {
                                $row_p = $result_p->fetch_assoc();
                                $result1 = $GLOBALS['conn']->query("SELECT name FROM markets WHERE id='$row_p[market_id]'");
                                $row1 = $result1->fetch_assoc();
                                echo "
                            <tr class='tr'>
                                <td>$row_p[name]</td>
                                <td>$ro[quantity]</td>
                            </tr>";
                            }
                        }
                    }
                    else echo " ";
                }
                else $GLOBALS['conn']->error;
            }
                else $GLOBALS['conn']->error;
    }
    ///////////////////////////////////////////////
    function checkout_b(){
        $res_c = $GLOBALS['conn']->query("SELECT product_id,market_id,price,quantity,date FROM cache WHERE user_id='$GLOBALS[uid]'");
        if($res_c->num_rows > 0){
            $row_c = $res_c->fetch_assoc();
            $res_mid = $GLOBALS['conn']->query("SELECT max(id) FROM bags");
            echo "1";
            if($res_mid){
                $row_mid = $res_mid->fetch_assoc();
                $bid = $row_mid['max(id)'];
                $bid++;
            }
            else $bid = 1;
            $product = $row_c['product_id'];
            $market = $row_c['market_id'];
            $quantity = $row_c['quantity'];
            $price = $row_c['price'];
            $date = $row_c['date'];
            $GLOBALS['conn']->query("INSERT INTO bags (id,user_id,product_id,market_id,quantity,price,date) VALUES ('$bid','$GLOBALS[uid]','$product','$market','$quantity','$price','$date')");
            while($row_c = $res_c->fetch_assoc()){
                $product = $row_c['product_id'];
                $market = $row_c['market_id'];
                $quantity = $row_c['quantity'];
                $price = $row_c['price'];
                $GLOBALS['conn']->query("INSERT INTO bags (id,user_id,product_id,market_id,quantity,price,date) VALUES ('$bid','$GLOBALS[uid]','$product','$market','$quantity','$price','$date')");
            }
            $GLOBALS['conn']->query("TRUNCATE TABLE cache");
            $res_b = $GLOBALS['conn']->query("SELECT DISTINCT market_id FROM bags WHERE id='$bid'");
            if($res_b){
                $row_b = $res_b->fetch_assoc();
                if($row_b){
                    $market = $row_b['market_id'];
                    $date = date('Y-m-d h:i');
                    echo $date;
                    $GLOBALS['conn']->query("INSERT INTO operations (market_id,bag_id,state,order_date) VALUES ('$market','$bid','not yet','$date')");
                    echo $GLOBALS['conn']->error;

                    while($row_b = $res_b->fetch_assoc()){
                        $market = $row_b['market_id'];
                        $GLOBALS['conn']->query("INSERT INTO operations (market_id,bag_id,state,order_date) VALUES ('$market','$bid','not yet','$date')");
                    }

                }
            }
        }

    }

    /////////////////////////////////////////////////////////////////////////////////////////
    function bag_done($bid){
        $res_op = $GLOBALS['conn']->query("UPDATE operations SET state='Done' WHERE bag_id='$bid'");
        if($res_op)
            echo "Done";
        else echo "touib";
    }
    //////////////////////////////////////////////////////////////////////////////////
    function meals_add(){
        $name = htmlspecialchars($_REQUEST['n']);
        $color = htmlspecialchars($_REQUEST['c']);
        if(isset($GLOBALS['uid']))
            $GLOBALS['conn']->query("INSERT INTO meals (name,user_id,color) VALUES ('$name','$GLOBALS[uid]','$color')");
    }
    ////////////////////////////////////
    function meals_b_f(){
        if(isset($GLOBALS['uid'])){
            $res = $GLOBALS['conn']->query("SELECT name,color FROM meals WHERE user_id='$GLOBALS[uid]' ORDER BY id ");
            if($res){
                $row = $res->fetch_assoc();
                echo "<div class='meal' style='background:#" . $row['color'] . ";'>" . $row['name'] . "</div>";
                while($row = $res->fetch_assoc()){
                    echo "<div class='meal' style='background:#" . $row['color'] . ";'>" . $row['name'] . "</div>";
                }   
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    function meals_pick(){
            $res = $GLOBALS['conn']->query("SELECT DISTINCT name,color FROM meals ORDER BY RAND()");
            if($res){
                while($row = $res->fetch_assoc()){
                    if(isset($GLOBALS['uid'])){
                        $exist = $GLOBALS['conn']->query("SELECT name,color FROM meals WHERE name='$row[name]' AND color='$row[color]' AND user_id='$GLOBALS[uid]'");
                        if($exist->num_rows == 0){
                            $erow = $exist->fetch_assoc();
                            $name = $row['name'];
                            $color = $row['color'];                     
                            echo "<div class='meal_wrap'><div class='mmeal' style='background:#" . $color . ";'>" . $name . "</div><div class='mplus' style='background:#" . $color . ";' title='Add to my list' onclick='meals_adds(\"".$name."\",\"".$color."\")'>+</div></div>";
                        }
                    }
                    else{
                        $name = $row['name'];
                        $color = $row['color'];                     
                        echo "<div class='meal_wrap'><div class='mmeal' style='background:#" . $color . ";'>" . $name . "</div><div class='mplus' style='background:#" . $color . ";' title='Add to my list' onclick='meals_adds(\"".$name."\",\"".$color."\")'>+</div></div>";
                    }
                }
            }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    function market_update($id){
        if(isset($_FILES['market_image'])){
            echo "<br>upload is set<br>";
            
            $target_dir = $_SESSION[de]."/uploads/ ";
            $ex = explode(".",$_FILES['market_image']['name']);
            $_FILES['market_image']['name'] = $id.".jpg";
            echo $_FILES['market_image']['name'];
            $target_file = $target_dir . basename($_FILES["market_image"]["name"]);
            $uploadOk = 1;
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            // Check if image file is a actual image or fake image
            
                $check = getimagesize($_FILES["market_image"]["tmp_name"]);
                if($check !== false) {
                    echo "File is an image - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }
            
            // Check if file already exists
            if (file_exists($target_file)) {
                unlink($target_file);
                echo "Sorry, file already exists.";
                $target_dir = $_SESSION[de]."/uploads/ ";
            $ex = explode(".",$_FILES['market_image']['name']);
            $_FILES['market_image']['name'] = $id.".jpg";
            echo $_FILES['market_image']['name'];
            $target_file = $target_dir . basename($_FILES["market_image"]["name"]);
            $uploadOk = 1;
            
            }
            // Check file size
            if ($_FILES["market_image"]["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["market_image"]["tmp_name"], $target_file)) {
                    echo "The file ". basename( $_FILES["market_image"]["name"]). " has been uploaded.";
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }
            echo "<br>process successfully done";
            header("Location: $_SESSION[de]/home");
        }
        else die( "where file!");
    }

//--------------------------------------------------------------------------------------------------
    function search_out($v){
        $result = $GLOBALS['conn']->query("SELECT market_id,name,id FROM products WHERE name LIKE '$v%'");
        if($result){
            while($row = $result->fetch_assoc()){
                echo "
                    <div class='search_element'><a href='$_SESSION[de]/products/?id=$row[market_id]&p=$row[id]' dir='auto'>$row[name]</a></div>
                ";
            }
        }
    }
    ob_end_flush();
