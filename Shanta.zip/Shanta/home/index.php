<?php 
    include_once '../initi.php';
    //else header("Location: ../sign.php");
 ?>
<!DOCTYPE html> 

<html>
<head>
  <title>Shanta | Home page</title>
  <?php 
    include_once '../navbar.php';
    if(!empty($_SESSION['user_name']) || empty($_SESSION['user_name'])){
            if(!isset($_SESSION['major']) || $_SESSION['major'] != "market_admin" ){
              if(isset($_COOKIE['last_loc']))
                echo "<input type='hidden' id='last_sel_val' value='".$_COOKIE['last_loc']."'> <script>select_market(document.getElementById('last_sel_val'));</script>"; 
                  echo '
                  <section id="location">
                          <div id="loc_sel">
                          
                          <div id="loc_left" style="display:inline-block;color:white;text-shadow:0 0 2px #2b2b2b">
                            <i class="fa fa-map-marker fa-3x" aria-hidden="true"></i>
                          </div>

                          <div id="loc_right" style="display:inline-block">

                          <div id="p" style="color:white;text-shadow:0 0 2px #2b2b2b">Select your location:</div>
                          
                          <select name="governorate" onchange="select_market(this);setTimeout(function(){height11();},800);"  class="location" id="markets_loc" placeholder="Select your Governorate/state" required>
                                                          ';
                $result = $GLOBALS['conn']->query("SELECT DISTINCT governorate FROM markets ");
                if($result)
                    $row = $result->fetch_assoc();ini_set('display_errors', 1);
                if($row){
                    echo "  
                              <option value='' selected>Select your governorate/city</option>
                              <option value='$row[governorate]'>$row[governorate]</option>
                      "; 
                    while($row = $result->fetch_assoc()){
                              echo "
                              <option value='$row[governorate]'>$row[governorate]</option>
                      ";    
                    }
                }
                    echo '</select>
                      </div>
                    </div>
                <div id="location1"></div></section>';
         }
        else if($_SESSION['major'] != "consumer"){
               echo "<div id='marketing'>$_SESSION[market_build_error]
                          
                  <form action='funcs.php?t=markets-build' method='post' enctype='multipart/form-data'>
                                  <p>New shop info.</p>
                                  <input type='file' name='market_image' placeholder='Image of market' title='Market image'>    
                    <input type='text' name='name' placeholder='Market name' required>
                    <select id='market_type' name='type' onchange='if(this.value == \"others\")
            document.getElementById(\"others\").style.display = \"inline-block\";
            else {document.getElementById(\"others\").style.display = \"none\";document.getElementById(\"others\").value = \"\";}' required>
                        <script>market_type_f();</script>                       
                    </select>
                    <input type='text' style='display:none' id='others' placeholder='Type of things you sell' name='others'>
                    <input type='text' name='telephone' placeholder='Telephone number' required>
                    <input type='text' name='telephone2' placeholder='optional: Telephone 2 '>
                    <select name='governorate' placeholder='market governorate/city' required> 
                          <option value='6th of October'>6th of October</option>
                          <option value='Al Sharqia'>Al Sharqia</option>
                          <option value='Alexandria'>Alexandria</option>
                          <option value='Aswan'>Aswan</option>
                          <option value='Asyut'>Asyut</option>
                          <option value='Beheira'>Beheira</option>
                          <option value='Beni Suef'>Beni Suef</option>
                          <option value='Cairo'>Cairo</option>
                          <option value='Dakahlia'>Dakahlia</option>
                          <option value='Damietta'>Damietta</option>
                          <option value='Faiyum'>Faiyum</option>
                          <option value='Gharbia'>Gharbia</option>
                          <option value='Giza'>Giza</option>
                          <option value='Helwan'>Helwan</option>
                          <option value='Ismailia'>Ismailia</option>
                          <option value='Kafr el-Sheikh'>Kafr el-Sheikh</option>
                          <option value='Luxor'>Luxor</option>
                          <option value='Matrouh'>Matrouh</option>
                          <option value='Minya'>Minya</option>
                          <option value='Monufia'>Monufia</option>
                          <option value='New Valley'>New Valley</option>
                          <option value='North Sinai'>North Sinai</option>
                          <option value='Port Said'>Port Said</option>
                          <option value='Qalyubia'>Qalyubia</option>
                          <option value='Qena'>Qena</option>
                          <option value='Red Sea'>Red Sea</option>
                          <option value='Sohag'>Sohag</option>
                          <option value='South Sinai'>South Sinai</option>
                          <option value='Suez'>Suez</option>

                      </select>
                      <input type='submit' value='Add Market' name='submit' title='Add new market'>
                  </form>
                 ";
                  $result1 = $GLOBALS['conn']->query("SELECT id,name,type,governorate,telephones FROM markets WHERE user_id='$_SESSION[user_id]'");
                if($result1){
                    while($row = $result1->fetch_assoc()){
                      $result2 = $GLOBALS['conn']->query("SELECT count(id) as count FROM products WHERE market_id=$row[id]");
                      $row1=$result2->fetch_assoc();
                      echo "
                            <div class='market'>
                                <a href='../products/?id=$row[id]'><img class='m_i' src='$_SESSION[de]/uploads/$row[id].jpg'></a>
                                <div style='width:100%;'><a class='m_n' href='../products/?id=$row[id]'>$row[name]</a></div>
                                <button class='m_b' onclick='document.getElementById(\"m_i_u$row[id]\").style.display = \"block\";'>Update image</button>
                                <form id='m_i_u$row[id]' method='post' enctype='multipart/form-data' action='funcs.php?t=market-update&id=$row[id]' style='display:none;overflow:hidden;'>
                                    <input type='file' name='market_image'>
                                    <input type='submit' value='Update' style='display:inline-block;'>
                                    <input type='submit' onclick='$(\"m_i_u$row[id]\").style.display=\"none\";return false;' value='Cancel' style='background:#c54b4b;display:inline-block;'>
                                </form>
                                <p class='m_t'>sells $row[type]</p>
                                <a class='m_t' href='tel:$row[telephones]'>$row[telephones]</a>
                                <p class='m_l' ><i class='fa fa-th' aria-hidden='true'></i> $row1[count] Products</p>
                                <p class='m_l' ><i class='fa fa-map-marker' aria-hidden='true'></i> $row[governorate]</p>
                            </div>
                       ";
                  }
              }
              echo "</div>";
        }
    }
      else {
                 echo "
                     <div id='info'>
                             <div id='intro' class='inf'>
                                     <p>Welcome to our site,<br><small style='font-size: 21px;'>This site is for making shopping easy for you.</small></p>
                             </div>  
                             <div id='how' class='inf'>
                                     <div id='how_customer' class='inf'>
                                             <h3>How to use the site as a customer:</h3>
                                             <ul>
                                                     <li>•Sign up as a Customer</li>
                                                     <li>•Select your current city</li>
                                                     <li>•Select the market you like</li>
                                                     <li>•Select products you need</li>
                                                     <li>•Click Checkout</li>
                                             </ul>   
                                     </div>
                                     <div id='how_admin' class='inf'>
                                             <h3>How to use the site as a Market admin:</h3>
                                             <ul>
                                                     <li>•Sign up as a market admin</li>
                                                     <li>•Enter Your market's info</li>
                                                     <li>•Enter The products you have in the market</li>
                                                     <li>*Update the prices and products daily</li>
                                             </ul>   
                                     </div>
                             </div>    
                 ";
        }
        include_once '../footer.php';
    ob_end_flush();
     ?>