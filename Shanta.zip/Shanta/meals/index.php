<?php 
    include_once '../initi.php';
    //else header("Location: ../sign.php");
 ?>
<!DOCTYPE html> 

<html>
<head>
  <title>Shanta | Meals</title>
  <link rel='stylesheet' href='../css/meals.css'>
  <?php 
  	$meals = 0;
    include_once '../navbar.php';

    echo '
		<div id="meals_b"></div>
    	<script>
    	var xml = new XMLHttpRequest;
	    xml.onreadystatechange = function(){
	        if(this.status == 200 && this.readyState == 4){
	            if(this.responseText.length > 46){
	                console.log(this.responseText.length);
	            	$("meals_b").innerHTML = this.responseText;
	        	}
	        meals_right();
	        }
	    }
	    xml.open("post",de+"/funcs/?t=meals-pick",true);
	    xml.send();
	
</script>
    ';

    include_once "../footer.php";
    ?>