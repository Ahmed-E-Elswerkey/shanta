<!DOCTYPE html>
<html>
    <head>
        <title>Shanta | Payment</title>
        <link rel='icon' href='./icon.png'>
        <script src='./js.js'></script>
    </head>
    <body>
        <?php

    require_once 'C:\XAMPP\htdocs\braintree-php-3.25.0/lib/Braintree.php';
    
    Braintree\Configuration::environment('sandbox');
    Braintree\Configuration::merchantId('qkz9rqgbk3w4knvs');
    Braintree\Configuration::publicKey('27nkzr599pg8jykw');
    Braintree\Configuration::privateKey('5d68bbf459f415c1259cb73427185792');
    ?>

        <form id="checkout" method="post" action="./payment.php" autocomplete="true">
            <div id="payment-form"></div>
            <input type="submit" value="Pay $1000000">
        </form>

        <script src="https://js.braintreegateway.com/js/braintree-2.32.1.min.js"></script>
        <script src="https://www.paypalobjects.com/api/checkout.js" data-version-4></script>
        <script>
            // We generated a client token for you so you can test out this code
            // immediately. In a production-ready integration, you will need to
            // generate a client token on your server (see section below).
            var clientToken = "<?php echo($clientToken = Braintree_ClientToken::generate()); ?>";

            braintree.setup(clientToken, "dropin", {
            container: "payment-form"
            });
        </script>
    </body>
</html>


