// var start = true;
// setTimeout(function(){start=false;},1000);
// for(var i=0;start; i++){
// 	if(!start){
// 		break;
// 		console.log(i);
// 	}
// 	i++;
// }