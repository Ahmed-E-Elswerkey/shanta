<?php

    require_once 'C:\XAMPP\htdocs\braintree-php-3.25.0/lib/Braintree.php';
    
    Braintree\Configuration::environment('sandbox');
    Braintree\Configuration::merchantId('qkz9rqgbk3w4knvs');
    Braintree\Configuration::publicKey('27nkzr599pg8jykw');
    Braintree\Configuration::privateKey('5d68bbf459f415c1259cb73427185792');
    
 //    $gateway = new Braintree_Gateway(array(
 //    'accessToken' => useYourAccessToken,
	// ));

 	$nonceFromTheClient = $_POST["payment_method_nonce"];
    /* Use payment method nonce here */
    $result = Braintree_Transaction::sale([
        'amount' => '20000.00',
        'paymentMethodNonce' => $nonceFromTheClient,
        'options' => [
            'submitForSettlement' => True
        ]
    ]);

 // echo Braintree_Transaction::processorResponseCode;   