<?php 
	include_once '../initi.php';
    if(isset($_REQUEST['id']))
           { $m = "WHERE market_id='$_REQUEST[id]'"; $id = $_REQUEST['id'];}
    else header("Location: ../");
	$result = $GLOBALS['conn']->query("SELECT * FROM products $m");
	if($result)
		$row = $result->fetch_assoc();
    $products = $id;
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Shanta | Products</title>
 	<link rel="stylesheet" type="text/css" href="../css/products.css">
    <style id='products_style'></style>
        <?php
        echo '
        
        <style>
        *{z-index:1;}
                body:before{
                        content:"";
                        background:linear-gradient(45deg,rgb(110, 47, 47),rgba(59, 59, 113, 0.30196078431372547)),url("../uploads/'.$_REQUEST['id'].'.jpg") no-repeat fixed ;
                        background:linear-gradient(45deg,rgb(110, 47, 47),rgba(59, 59, 113, 0.30196078431372547)),url("../uploads/'.$_REQUEST['id'].'.jpg") no-repeat;
                        position: absolute;
                        top: 0;
                        overflow: hidden;
                        width: 100%;
                        height:100%;
                        background-size: cover;
                        background-position:center;
                        z-index: -1;
                }
        </style>
        
        ';
        
        $result1 = $GLOBALS['conn']->query("SELECT name FROM markets WHERE id='$id'");
         if($result1){
            $row1 = $result1->fetch_assoc();
            $m_name = $row1['name'];
        }
        include_once '../navbar.php';
        if(isset($_REQUEST['p'])){
            $id = $_REQUEST['p'];
            //When clicking on a product in the search list, this page sill open and direct itself to product position
            echo "
              <script>
              setTimeout(function(){                
                var element = document.getElementsByClassName('consumer');
                for(var i=0;i<element.length;i++){
                    if(element[i].getAttribute('data-product') == $id){
                        window.scrollTo(0,element[i].getBoundingClientRect().bottom-150);
                        element[i].parentElement.parentElement.classList.add('flash');  
                    }
                }
},300);
                var element = document.getElementsByClassName('consumer');
                for(var i=0;i<element.length;i++){
                    if(element[i].getAttribute('data-product') == $id){
                        window.scrollTo(0,element[i].getBoundingClientRect().bottom);
                        element[i].parentElement.parentElement.classList.add('flash');  
                    }
                }
              </script>  
            ";
        }
        echo "<div id='container'>
                <div id='market_name'>".$row1['name']." </div>
                <div id='table_style'>
                    <fieldset>
                    <legend>Display mode:</legend>
                    <button id='products_list'><i class=\"fa fa-list\" aria-hidden=\"true\"></i> <input type='radio' name='product_style' id='pl_r'></button>
                    <button id='products_blocks'><i class=\"fa fa-th\" aria-hidden=\"true\"></i><input type='radio' name='product_style' id='pb_r'></button>
                    </fieldset>
                </div>";
        
        if(isset($_SESSION['major']) &&  $_SESSION["major"] == "market_admin"){
                echo '<div style="background:white;padding:0.5rem;box-shadow:0 0 3px 0.4px black"> <p id="m_h" onclick="document.location.href=\''.$_SESSION['de'].'/user/?id='.$_REQUEST["id"].'\';">Demands</p>
                <form id="products_fill" action="'.$_SESSION['de'].'/funcs/?t=products-filling" method="post">
                        <input type="text" name="name" placeholder="Product name" required>
                        <input type="text" name="price" placeholder="Product price" required>
                        <input type="text" name="type" placeholder="Product type" required>
                        <input type="hidden" value="'.$id.'" name="market_id" required> 
                        <input type="submit" name="submit">
                </form>';
        }

        if($row)
        {$i=1;

            echo "
                
                <script src='../js/products.js' type=\"text/javascript\"></script>

                <table>
                <tr>
                    <th></th>
                    <th class='consumer'> </th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Type</th>
                    
                </tr>
                <tr class='tr'>
                    <td>$i</td>
                    <td class='consumer'><input type='checkbox' class='check' data-id='$i' onchange='checkbox(this)' data-type='product' value='$row[id]' name='product[]'/></td>
                                        
                    <td>$row[name]</td>
                    <td>$row[price]* <input type='number' title='quantity of the product' class='consumer' id='q".$i."' onchange='checkbox(this)' disabled='true' data-product='$row[id]' data-type='quantity'  value='' name='quantity[]' min='0.25'/></td>
                    <td>$row[type]</td>
                    
                </tr>
 				";
 				while($row = $result->fetch_assoc()){
 					if($row){ $i++; echo "
 				<tr class='tr'>
                    <td>$i</td>
 					<td class='consumer'>
                        <input type='checkbox' class='check' data-id='$i' onchange='checkbox(this)' data-type='product' value='$row[id]' name='product[]'/>
                    </td>
 					<td>$row[name]</td>
 					<td>
                        $row[price]* <input type='number' title='quantity of the product' class='consumer' id='q$i' onchange='checkbox(this)' disabled='true' data-product='$row[id]' data-type='quantity'  value='' name='quantity[]' min='0.25'/>
                    </td>
 					<td>$row[type]</td>
 					
 				</tr>
 				";}
 				}
 			echo "</table>";
                        

 		}
 	echo "</div></div>";
        echo "
         <script>
 	 	";
        if(isset($_SESSION['user_id'])){
            $result_c = $GLOBALS['conn']->query("SELECT product_id,quantity FROM cache WHERE user_id='$_COOKIE[user_id]' AND market_id='$_REQUEST[id]'");
            if($result_c)
            {
                $c_i = 0;
                $i_i = 0;
                echo "\n var q;\n";
                while($row_c = $result_c->fetch_assoc()){
                    echo "
////////////////////////////////////////////////////
if(document.querySelector(\"input[value='".$row_c['product_id']."']\") != undefined){
    var conchange = document.querySelector(\"input[value='".$row_c['product_id']."']\").onchange;
    document.querySelector(\"input[value='".$row_c['product_id']."']\").onchange = 'return false;';
    document.querySelector(\"input[value='".$row_c['product_id']."']\").click();
    q = document.querySelector(\"input[value='".$row_c['product_id']."']\").getAttribute(\"data-id\");
    document.getElementById(\"q\" + q).value = ".$row_c['quantity'].";
    document.getElementById(\"q\" + q).disabled = false;
    document.querySelector(\"input[value='".$row_c['product_id']."']\").onchange = conchange;
}
/////////////////////////////////////////////////////";
                    $i_i++;
                }
            }
        }
 	 echo "
 	 </script>
 	 ";
        include_once '../footer.php';
     
        ?>