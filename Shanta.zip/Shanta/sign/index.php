<?php 
	ob_start();
	include_once '../initi.php';

	if(!isset($_SESSION['sign_error']))
		$_SESSION['sign_error'] = "";
	if(isset($_COOKIE['user_name']))
		header("Location: ".$_SESSION['de']);
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Shanta | Registeration</title>
	<link rel="stylesheet" type="text/css" href="../css/sign.css">

	<?php $sign_p = 0; include_once '../navbar.php'; ?>

	<div id="body">

	<?php
     echo "<script>console.log('$_SERVER[HTTP_HOST]');</script>";
	 echo $_SESSION['sign_error']; ?>

	<div id="sign_up_d">
			<button id="sign_up" onclick="sign_toggle(this)">Sign up</button>
			<form method="post" action="<?php echo $_SESSION['de']; ?>/funcs/?t=sign-up" id="sign_up_form" >
				
				<input class="input" type="text" name="user_name" placeholder="Full Name" required="required">
				<input class="input" type="email" name="user_email" placeholder="E-mail Here" required="required">

				<select name='governorate' alt='Select the governorate you currently live in' required>
                          <option value=''>Your Governorate..</option>
                          <option value='6th of October'>6th of October</option>
                          <option value='Al Sharqia'>Al Sharqia</option>
                          <option value='Alexandria'>Alexandria</option>
                          <option value='Aswan'>Aswan</option>
                          <option value='Asyut'>Asyut</option>
                          <option value='Beheira'>Beheira</option>
                          <option value='Beni Suef'>Beni Suef</option>
                          <option value='Cairo'>Cairo</option>
                          <option value='Dakahlia'>Dakahlia</option>
                          <option value='Damietta'>Damietta</option>
                          <option value='Faiyum'>Faiyum</option>
                          <option value='Gharbia'>Gharbia</option>
                          <option value='Giza'>Giza</option>
                          <option value='Helwan'>Helwan</option>
                          <option value='Ismailia'>Ismailia</option>
                          <option value='Kafr el-Sheikh'>Kafr el-Sheikh</option>
                          <option value='Luxor'>Luxor</option>
                          <option value='Matrouh'>Matrouh</option>
                          <option value='Minya'>Minya</option>
                          <option value='Monufia'>Monufia</option>
                          <option value='New Valley'>New Valley</option>
                          <option value='North Sinai'>North Sinai</option>
                          <option value='Port Said'>Port Said</option>
                          <option value='Qalyubia'>Qalyubia</option>
                          <option value='Qena'>Qena</option>
                          <option value='Red Sea'>Red Sea</option>
                          <option value='Sohag'>Sohag</option>
                          <option value='South Sinai'>South Sinai</option>
                          <option value='Suez'>Suez</option>
                      </select>

				<select name="major" onchange="select_change(this)" onkeyup="select_change(this)" placeholder="Select your major" required="required">
					<option value="">Select account type...</option>
					<option value="consumer">Customer</option>
					<option value="market_admin">Market admin</option>
				</select>

				<input class="input" type="password" name="password" placeholder="Password Here" required="required">
				<input type="submit" name="submit" value='Register'>
			</form>
		</div>

		<div id="sign_in_d">
			<button id="sign_in" onclick="sign_toggle(this)">Sign in</button>
			<form action="<?php echo $_SESSION['de']; ?>/funcs/?t=sign-in" style="display:none;" id="sign_in_form" method="post">
				<input class="input" type="email" name="user_email" placeholder="E-mail Here" required="required">
				<input class="input" type="password" name="password" placeholder="Password Here" required="required">
				<input type="submit" name="" value='Sign in'>
			</form>
		</div>
		
	</div>
        <?php 
        include_once '../footer.php'; 
		ob_end_flush(); 
		?>